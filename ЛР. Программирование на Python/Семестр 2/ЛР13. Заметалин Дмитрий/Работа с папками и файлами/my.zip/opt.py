import random
import time


random.seed(42)


def measure(title, func):
    start = time.perf_counter()
    result = func()
    finish = time.perf_counter()

    print(f"{title}: {finish - start:.6f} сек")
    return result


print("=== Как ускорить код в 10 раз ===")


print("\n--- Пример 1 ---")

# здесь пишем код


print("\n--- Пример 2 ---")

# здесь пишем код


print("\n--- Пример 3 ---")

# здесь пишем код


print("\n--- Пример 4 ---")

# здесь пишем код


print("\n--- Выводы ---")